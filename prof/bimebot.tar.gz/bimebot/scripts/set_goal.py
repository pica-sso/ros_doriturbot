# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import rospy
from actionlib import SimpleActionClient
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Point, Quaternion
from tf.transformations import quaternion_from_euler
PI = 3.14159265359




def move_base_to(x, y, yaw=0):
    client = SimpleActionClient("move_base", MoveBaseAction)
    while (not client.wait_for_server(rospy.Duration(5))):
        rospy.loginfo("Waiting for the move_base action server to come up")
        
    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id = "map"
    goal.target_pose.header.stamp = rospy.Time.now()
    goal.target_pose.pose.position = Point(x, y, 0)
    goal.target_pose.pose.orientation = Quaternion(*quaternion_from_euler(0, 0, yaw))
    
    rospy.loginfo("Sending goal")
    client.send_goal(goal)
    wait = client.wait_for_result()
    if not wait:
        rospy.logerr("Action server not avaliable!")
        rospy.signal_shutdown("Action server not available!")
    else:
        return client.get_result()




if __name__ == "__main__":
    goal_positions = [( 1.00,  1.90, PI/2),
                      (-6.55, -2.80, 0),
                      (-1.35,  3.90, PI),
                      ( 5.85, -4.65, 0),
                      ( 6.45,  4.20, PI),
                      ( 1.00,  1.90, PI/2)]

    rospy.init_node("set_navigation_goal")
    
    for x, y, yaw in goal_positions:
        result = move_base_to(x, y, yaw)
        print(f"******** New Goal received ***** {result}")
        if result:
            continue
        else:
            rospy.loginfo("The move_base failed to get to goal for some reason")
            break


